-- Q1: Find all players who represent India
SELECT name, role, runs
FROM players
WHERE team = 'India';

-- Q2: Show all matches played
SELECT team1, team2, status
FROM matches;

-- Q3: List top run scorers
SELECT name, runs
FROM players
ORDER BY runs DESC
LIMIT 10;

-- Q4: Count players by role
SELECT role, COUNT(*) AS total_players
FROM players
GROUP BY role;
