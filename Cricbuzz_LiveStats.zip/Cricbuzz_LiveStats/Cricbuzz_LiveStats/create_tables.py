from utils.db_connection import get_connection

conn = get_connection()
cursor = conn.cursor()

# Players table
cursor.execute("""
CREATE TABLE IF NOT EXISTS players (
    player_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    team TEXT,
    role TEXT,
    runs INTEGER
)
""")

# Matches table
cursor.execute("""
CREATE TABLE IF NOT EXISTS matches (
    match_id INTEGER PRIMARY KEY AUTOINCREMENT,
    team1 TEXT,
    team2 TEXT,
    status TEXT
)
""")

conn.commit()
conn.close()

print("Tables created successfully")
