from utils.db_connection import get_connection

conn = get_connection()
cursor = conn.cursor()

# Insert players
players = [
    ("Virat Kohli", "India", "Batsman", 12000),
    ("Rohit Sharma", "India", "Batsman", 10000),
    ("Ben Stokes", "England", "All-rounder", 6000)
]

cursor.executemany(
    "INSERT INTO players (name, team, role, runs) VALUES (?, ?, ?, ?)",
    players
)

# Insert matches
matches = [
    ("India", "England", "India won by 5 wickets"),
    ("Australia", "Pakistan", "Australia won by 80 runs")
]

cursor.executemany(
    "INSERT INTO matches (team1, team2, status) VALUES (?, ?, ?)",
    matches
)

conn.commit()
conn.close()

print("Data inserted successfully")
