import streamlit as st
from utils.api import get_live_matches

st.title("📡 Live Cricket Matches (RapidAPI)")

data = get_live_matches()

if data and "typeMatches" in data:
    st.success("Live data fetched successfully")

    for match_type in data["typeMatches"]:
        st.subheader(match_type.get("matchType", "Unknown"))

        for series in match_type.get("seriesMatches", []):
            wrapper = series.get("seriesAdWrapper")
            if wrapper:
                st.write("📌 Series:", wrapper.get("seriesName"))

                for match in wrapper.get("matches", []):
                    info = match.get("matchInfo", {})
                    t1 = info.get("team1", {}).get("teamName", "")
                    t2 = info.get("team2", {}).get("teamName", "")
                    status = info.get("status", "")
                    st.write(f"**{t1} vs {t2}**")
                    st.caption(status)
else:
    st.warning("Live data not available (API limitation)")
