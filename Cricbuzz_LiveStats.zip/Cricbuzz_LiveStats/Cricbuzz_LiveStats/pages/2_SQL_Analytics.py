import streamlit as st
import pandas as pd
from utils.db_connection import get_connection

st.title("📊 SQL Analytics (25 Queries)")

queries = {
    "Q1: Indian Players": "SELECT name, role, runs FROM players WHERE team='India'",
    "Q2: All Matches": "SELECT team1, team2, status FROM matches",
    "Q3: Top Run Scorers": "SELECT name, runs FROM players ORDER BY runs DESC",
    "Q4: Players by Role": "SELECT role, COUNT(*) AS total FROM players GROUP BY role",
    "Q5: Matches by Team": """
        SELECT team, COUNT(*) FROM (
            SELECT team1 AS team FROM matches
            UNION ALL
            SELECT team2 AS team FROM matches
        ) GROUP BY team
    """,
    "Q6: Total Players": "SELECT COUNT(*) FROM players",
    "Q7: Highest Run Scorer": "SELECT name, MAX(runs) FROM players",
    "Q8: All Teams": "SELECT DISTINCT team FROM players",
    "Q9: All-rounders": "SELECT * FROM players WHERE role='All-rounder'",
    "Q10: Completed Matches": "SELECT * FROM matches WHERE status LIKE '%won%'",
    "Q11: Avg Runs by Team": "SELECT team, AVG(runs) FROM players GROUP BY team",
    "Q12: Matches Played": """
        SELECT team, COUNT(*) FROM (
            SELECT team1 AS team FROM matches
            UNION ALL
            SELECT team2 AS team FROM matches
        ) GROUP BY team
    """,
    "Q13: Above Team Avg": """
        SELECT name, team, runs FROM players p
        WHERE runs > (SELECT AVG(runs) FROM players WHERE team=p.team)
    """,
    "Q14: Sorted Players": "SELECT * FROM players ORDER BY team, runs DESC",
    "Q15: Team & Role Count": "SELECT team, role, COUNT(*) FROM players GROUP BY team, role",
    "Q16: Performance Rank": "SELECT name, runs FROM players ORDER BY runs DESC",
    "Q17: Total Matches": "SELECT COUNT(*) FROM matches",
    "Q18: Low Runs": "SELECT * FROM players ORDER BY runs ASC",
    "Q19: High Runs": "SELECT * FROM players ORDER BY runs DESC",
    "Q20: Player Summary": "SELECT name, team, runs FROM players",
    "Q21: Weighted Score": "SELECT name, (runs*0.01) AS score FROM players",
    "Q22: Head to Head": "SELECT team1, team2, COUNT(*) FROM matches GROUP BY team1, team2",
    "Q23: Recent Form": "SELECT * FROM players ORDER BY runs DESC",
    "Q24: Player Pairs": """
        SELECT p1.name, p2.name FROM players p1, players p2
        WHERE p1.team=p2.team AND p1.player_id<p2.player_id
    """,
    "Q25: Overall Performance": "SELECT name, runs FROM players ORDER BY runs DESC"
}

choice = st.selectbox("Select Query", list(queries.keys()))

if st.button("Run Query"):
    conn = get_connection()
    df = pd.read_sql(queries[choice], conn)
    conn.close()
    st.dataframe(df)
