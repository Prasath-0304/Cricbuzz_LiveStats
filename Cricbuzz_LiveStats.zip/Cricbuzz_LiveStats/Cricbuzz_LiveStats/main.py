import streamlit as st

st.set_page_config(page_title="Cricbuzz LiveStats", layout="wide")

st.title("🏏 Cricbuzz LiveStats")
st.subheader("Real-Time Cricket Insights & SQL-Based Analytics")

st.markdown("""
### 📌 Project Overview
This project is a RAPID-style real-time cricket analytics dashboard.

### ⚙️ Technologies Used
- Python
- Streamlit
- RapidAPI (Cricbuzz)
- SQLite (SQL Database)

### 📄 Pages in this Project
Use the sidebar to navigate:
- **Live Matches** → Real-time data from RapidAPI
- **SQL Analytics** → Execute all 25 SQL queries
- **CRUD Operations** → Add / Update / Delete players
""")
