from utils.api import get_live_matches

data = get_live_matches()
print(data)
