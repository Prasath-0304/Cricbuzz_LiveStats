import requests

API_KEY = "29e4f9bba9msha2cf9c6368cec9cp1dcbbejsn4ec0df2571dc"

URL = "https://cricbuzz-cricket.p.rapidapi.com/matches/v1/live"

HEADERS = {
    "X-RapidAPI-Key": API_KEY,
    "X-RapidAPI-Host": "cricbuzz-cricket.p.rapidapi.com"
}

def get_live_matches():
    response = requests.get(URL, headers=HEADERS)
    return response.json()
